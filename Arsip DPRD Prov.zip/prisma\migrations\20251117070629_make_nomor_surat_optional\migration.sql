-- AlterTable
ALTER TABLE "surat_masuk" ALTER COLUMN "nomorSurat" DROP NOT NULL;
